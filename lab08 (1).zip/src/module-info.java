module Guirdle {
    requires transitive javafx.controls;
    exports gurdle.gui;
}
